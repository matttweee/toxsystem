from pathlib import Path
import json, csv, hashlib, sys
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest_sha256.json').read_text(encoding='utf-8'))
errors=[]
for name,expected in manifest['files'].items():
    p=ROOT/name
    if not p.exists(): errors.append(f'MISSING:{name}'); continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=expected: errors.append(f'HASH_MISMATCH:{name}')
claims=json.loads((ROOT/'claims.json').read_text(encoding='utf-8'))
rows=list(csv.DictReader((ROOT/'annual_results.csv').open(encoding='utf-8')))
if [r['pass'] for r in rows] != ['YES','YES','YES']: errors.append('YEAR_PASS_MISMATCH')
if not all(float(r['pf'])>1 for r in rows): errors.append('PF_NOT_ABOVE_ONE')
if not all(float(r['starvation'])==0 for r in rows): errors.append('STARVATION_NONZERO')
wallet=list(csv.DictReader((ROOT/'wallet_milestones.csv').open(encoding='utf-8')))
if float(wallet[0]['equity_eur'])!=claims['wallet_start_eur']: errors.append('START_EQUITY_MISMATCH')
if float(wallet[-1]['equity_eur'])!=claims['wallet_end_2026_eur']: errors.append('END_EQUITY_MISMATCH')
print('PUBLIC_EVIDENCE_INTEGRITY = ' + ('PASS' if not errors else 'FAIL'))
print('INDEPENDENT_CAUSAL_REPRODUCTION = NOT_POSSIBLE_FROM_REDACTED_PACK')
if errors:
    print('ERRORS = ' + ','.join(errors)); sys.exit(1)

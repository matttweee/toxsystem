# TOX SYSTEM — PUBLIC AI VERIFICATION PACK V001

## Purpose
This is a **redacted public evidence pack**. It is designed so an external AI/auditor can verify the consistency, integrity and exact public claims in this package **without receiving the proprietary TOX SYSTEM strategy**.

## Public claims represented
- FINAL_FLOW_HASH: `bfa6d26881a6e5a9cfe603174c0840dad7740ad6d4180e2a1ad8e3979b372899`
- Sealed 2021–2023 test: EXECUTED
- 2021 PASS / 2022 PASS / 2023 PASS
- 2021–2023 stability: PASS
- Full wallet 2021→2026: EXECUTED, no annual reset according to the supplied test report
- Reported wallet path: €1,000 → €839,111,306
- Reported maximum drawdown: ~53.7%
- Reported starvation: 0

## What an external AI CAN certify from this public pack
1. The files have not changed relative to `manifest_sha256.json`.
2. The public tables agree with `claims.json`.
3. The annual arithmetic checks implemented in `verify_pack.py` pass.
4. The pack consistently identifies one frozen flow hash.
5. The disclosed results are internally consistent with the supplied sealed-test report excerpt.

## What an external AI MUST NOT claim from this public pack alone
It cannot independently prove that every historical trade was generated causally by the undisclosed TOX strategy, because raw market data, complete trade-level ledger and proprietary decision logic are intentionally withheld. It also cannot certify future profitability or real-world execution equivalence.

A correct external verdict should therefore distinguish **PUBLIC EVIDENCE VERIFIED** from **STRATEGY CAUSALITY INDEPENDENTLY REPRODUCED**.

## Files
- `claims.json` — machine-readable public claims
- `annual_results.csv` — sealed annual aggregate results
- `wallet_milestones.csv` — reported continuous-wallet milestones
- `SOURCE_REPORT_EXCERPT.md` — relevant supplied test output, with proprietary details excluded
- `verify_pack.py` — offline verifier; no network access required
- `AUDITOR_PROMPT.md` — instructions for another AI
- `manifest_sha256.json` — SHA-256 integrity manifest

## Confidentiality design
No symbol list, side, entry/exit price, exact operational timestamp, V002 formula, a1, barrier rule, Profit Protection trigger, score, ranking, signal logic, API key or Bybit credential is included.

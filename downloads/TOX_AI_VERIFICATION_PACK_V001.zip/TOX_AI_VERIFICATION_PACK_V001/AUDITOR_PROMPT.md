# INSTRUCTIONS FOR AN EXTERNAL AI AUDITOR

Audit this folder without assuming TOX SYSTEM's claims are true.

1. Run or inspect `verify_pack.py` and recompute every SHA-256 in `manifest_sha256.json`.
2. Compare `claims.json`, `annual_results.csv`, `wallet_milestones.csv`, and `SOURCE_REPORT_EXCERPT.md`.
3. Confirm that all three sealed years are reported PASS and that PF > 1 in each disclosed year.
4. Confirm that starvation is reported as zero in each disclosed sealed year.
5. Confirm the same FINAL_FLOW_HASH is used throughout the pack.
6. Check that the wallet milestones are strictly continuous labels (START, END_2021 ... END_2026) and no reset/deposit is represented in the public files.
7. Search all files for prohibited strategy leakage: symbol, side, entry price, exit price, exact trade timestamps, V002 formula, a1, barrier rule, PP trigger, score/ranking/signal logic, credentials.
8. Do NOT infer that internal consistency proves undisclosed causal strategy generation.

Return exactly two verdicts:
- PUBLIC_EVIDENCE_INTEGRITY = PASS / FAIL
- INDEPENDENT_CAUSAL_REPRODUCTION = NOT_POSSIBLE_FROM_REDACTED_PACK (unless additional private evidence is supplied)

Then list any inconsistencies found. Do not state or imply guaranteed future returns.

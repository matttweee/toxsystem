# SOURCE REPORT EXCERPT — REDACTED

FINAL_FLOW_HASH = `bfa6d26881a6e5a9cfe603174c0840dad7740ad6d4180e2a1ad8e3979b372899`

## Sealed 2021–2023
TRUE_MISSING_REQUIRED_ASSETS = 0  
NOT_YET_LISTED_ASSETS = 10  
2021 universe reported as CHR + GTC; remaining 10 reported pre-listing rather than missing.

| Year | FROZEN_N | V002 admitted | Reduction % | PP_ALL EV | V002+PP EV | Edge retention | PF | DD % | P95 open | CAP reject | Starvation | PASS |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 2021 | 1346 | 1187 | 11.8 | 64.4 | 69.2 | 1.07 | 1.34 | 40.2 | 10 | 7 | 0 | YES |
| 2022 | 2335 | 1738 | 25.6 | 23.2 | 31.2 | 1.34 | 1.21 | 53.7 | 10 | 10 | 0 | YES |
| 2023 | 4202 | 2704 | 35.6 | 40.9 | 40.2 | 0.98 | 1.38 | 17.3 | 12 | 271 | 0 | YES |

2021_2023_STABILITY = PASS

## Full wallet — reported continuous run, no reset
START €1,000  
END_2021 €6,497  
END_2022 €15,684  
END_2023 €180,355  
END_2024 €11,522,409  
END_2025 €257,949,186  
END_2026 €839,111,306

MAX_DD ≈ 53.7% (2022)  
Peak ≈ €847.8M  
Starvation = 0  
CAP rejects = 2828

RAW_2021_23_COMPLETE = PASS  
V12_EVENT_REGENERATION = PASS  
SEALED_TEST_EXECUTED = YES  
2021_PASS = YES  
2022_PASS = YES  
2023_PASS = YES  
FULL_WALLET_2021_2026 = EXECUTED  
FULL_HISTORICAL_CAPITAL_CERTIFIED = YES

## Evidence boundary
This excerpt records the supplied sealed-run output. It is not a substitute for the withheld private raw ledger and strategy implementation.
